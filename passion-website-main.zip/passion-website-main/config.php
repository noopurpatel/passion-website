<?php

$conn = mysqli_connect('localhost','root','','user_reg_db') or die('connection failed');

?>